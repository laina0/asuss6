<?php
	class Back_controller extends CI_Controller {
		public function __construct() {
			parent::__construct();
			$this->load->model('Categorie_model');
			$this->load->model('Produit_model');
			$this->load->model('Client_model');
		}

		public function backofficeindex(){
			$data['produits'] = $this->Produit_model->selectdetails();
			$data['categories'] = $this->Categorie_model->select();
			$this->load->view('table', $data);
		}

		public function insertproduit(){
			$nomproduit = $this->input->post('nomproduit');
			$idcategorie = $this->input->post('idcategorie');
			$description = $this->input->post('description');
			$config = array(
				'upload_path' => "./assets/images/",
				'allowed_types' => "gif|jpg|png|jpeg|pdf",
				'overwrite' => TRUE,
				'max_size' => 0,
				'max_height' => 0,
				'max_width' => 0
			);
			$this->load->library('upload');
			$this->upload->initialize($config);
			if($this->upload->do_upload('image')){
				$data = $this->upload->data();
				$this->Produit_model->insert($idcategorie, $nomproduit, $description, "assets/images/".$data['file_name']);
				$this->backofficeindex();
			} else {
				var_dump($this->upload->display_errors());
			}
		}
		
		public function insertcategorie(){
			$nomcategorie = $this->input->post('nomcategorie');
			$this->Categorie_model->insert($nomcategorie);
			$this->backofficeindex();
		}

		public function loginbackoffice(){
			$this->load->view('loginbackoffice');
		}

		public function auth(){
			$nom = $this->input->post('nom');
			$mdp = $this->input->post('mdp');
			$val = $this->Client_model->auth($nom, $mdp);
			// $data['val'] = $val;
			if(sizeof($val)){
				$data['produits'] = $this->Produit_model->selectdetails();
				$data['categories'] = $this->Categorie_model->select();
				$this->load->view('table', $data);
			} else {
				$data['message'] = 'Name/Password mismatch';
				$this->load->view('loginbackoffice');
			}
		}
	}
?>
