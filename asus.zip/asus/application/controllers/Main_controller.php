<?php
	class Main_controller extends CI_Controller {
		public function __construct() {
			parent::__construct();
			$this->load->model('Categorie_model');
			$this->load->model('Produit_model');
		}

		public function index(){
			$data['title'] = 'Asus Products | ASUS';
			$data['categories'] = $this->Categorie_model->select();
			$data['produits'] = $this->Produit_model->select();
			$data['nombreresultats'] = count($data['produits']);
			$this->load->view('index', $data);
		}

		public function listeparcategorie(){
			$idcateg = $this->input->get('idcateg');
			$data['categories'] = $this->Categorie_model->select();
			$data['produits'] = $this->Produit_model->getbycategorie($idcateg);
			$data['nombreresultats'] = count($data['produits']);
			$data['title'] = $data['categories'][$idcateg-1]->NOMCATEGORIE.' | Asus Products | ASUS';
			$this->load->view('index', $data);
		}

		public function detailproduit(){
			$idproduit = $this->input->get('idproduit');
			$data['categories'] = $this->Categorie_model->select();
			$data['produit'] = $this->Produit_model->getdetailproduit($idproduit);
			$data['title'] = $data['produit'][0]->NOMPRODUIT.' | '.$data['produit'][0]->NOMCATEGORIE.' | Asus Products | ASUS';
			$this->load->view('product', $data);
		}
	}
?>
