<?php
	class Produit_model extends CI_Model {
		public function select(){
			$query = $this->db->get('PRODUIT');
			return $query->result();
		}

		public function selectdetails(){
			$query = 'select * from PRODUIT join CATEGORIE on PRODUIT.IDCATEGORIE = CATEGORIE.IDCATEGORIE';
			$query = $this->db->query($query);
			return $query->result();
		}

		public function getbyid($idproduit){
			$query = 'select * from PRODUIT where IDPRODUIT ='.$idproduit;
			$query = $this->db->query($query);
			return $query->result();
		}

		public function getbycategorie($idcateg){			
			$query = 'select * from PRODUIT join CATEGORIE on PRODUIT.IDCATEGORIE = CATEGORIE.IDCATEGORIE where PRODUIT.IDCATEGORIE ='.$idcateg;
			$query = $this->db->query($query);
			return $query->result();
		}

		public function getdetailproduit($idproduit){
			$query = 'select * from PRODUIT join CATEGORIE on PRODUIT.IDCATEGORIE = CATEGORIE.IDCATEGORIE where IDPRODUIT ='.$idproduit;
			$query = $this->db->query($query);
			return $query->result();
		}

		public function insert($idcategorie, $nomproduit, $description, $image){
			$query = 'insert into PRODUIT(IDCATEGORIE, NOMPRODUIT, DESCRIPTION, IMAGE) values(
				'.$idcategorie.',
				"'.$nomproduit.'",
				"'.$description.'",
				"'.$image.'")';
			$query = $this->db->query($query);
		}
	}
?>
