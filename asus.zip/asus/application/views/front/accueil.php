<html>
	<head>
		<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/bootstrap.css'?>">	
		<script src="<?php echo base_url() . 'assets/js/jquery.js'?>"></script>
	</head>
	<body>
		<div class='container'>
			<div class='list-group-item'>
				<h1> Accueil</h1>
				<form method="POST" action="<?php echo base_url() . 'index.php/accueil_controller/ajouterFonction';?>">
					<input class='form-control' type='text' name='nom'/>
					<br/>
					<input class='form-control' type='text' name='prenom'/>
					<br/>
					<input type='submit' value='Enregistrer' class='btn btn-success'/>
					<a class='btn btn-info' href='<?php echo base_url() . "index.php/accueil_controller/liste" ?>'>
						Liste
					</a>
					
				</form>

				
				<input class='form-control' type='text' name='nom' id='nom'/>
				<br/>
				<input class='form-control' type='text' name='prenom'  id='prenom'/>
				<br/>
				<input type='submit' value='Enregistrer' onclick='verify()' class='btn btn-success'/>
				
				<div style='display:none;' id="cartmessage">Insertion effectué avec succes</div>
			</div>
		</div>
	</body>
</html>
<script>
	function verify(){
		var nom = $("#nom").val();
		var prenom = $("#prenom").val(); "prenom1" 

		if(nom.length == 0 || prenom.length == 0) {
			alert("Nom et prenom obligatoire");
			return false;
		}

		$.ajax(
			{
				type:"POST",
				url: "<?php echo base_url() . 'index.php/accueil_controller/ajouterFonctionAjax' ?>",
				data:{ nom:nom, prenom:prenom},
				success:function(response)
				{
					console.log(response);
					$('#cartmessage').show();
				},
				error: function() 
				{
					alert("Invalide!");
				}
			}
		);
	}
</script>
