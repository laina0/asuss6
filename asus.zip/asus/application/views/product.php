<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $title;?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="<?php echo $title;?>">
<meta name="keywords" content="asus
	<?php 
		echo ','.$produit[0]->NOMPRODUIT;
	?>
">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/'?>styles/bootstrap4/bootstrap.min.css">
<link href="<?php echo base_url().'assets/'?>plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/'?>plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/'?>plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/'?>plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/'?>styles/product_styles.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/'?>styles/product_responsive.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/'?>css/mycss.css">

</head>

<body>

<div class="super_container">
	
	<!-- Header -->
	
	<?php include('templates/header.php'); ?>

	<!-- Single Product -->

	<div class="single_product">
		<div class="container">
			<div class="row">

				<!-- Images -->
				<div class="col-lg-2 order-lg-1 order-2">
					<ul class="image_list">
						<li data-image="<?php echo base_url().''.$produit[0]->IMAGE?>"><img src="<?php echo base_url().''.$produit[0]->IMAGE?>" alt=""></li>
					</ul>
				</div>

				<!-- Selected Image -->
				<div class="col-lg-5 order-lg-2 order-1">
					<div class="image_selected"><img src="<?php echo base_url().''.$produit[0]->IMAGE?>" alt=""></div>
				</div>

				<!-- Description -->
				<div class="col-lg-5 order-3">
					<div class="product_description">
						<div class="product_category"><?php echo $produit[0]->NOMCATEGORIE?></div>
						<div class="product_name"><h2><strong class="simplestrong"><?php echo $produit[0]->NOMPRODUIT?></strong></h2></div>
						<div class="product_text"><p><?php echo $produit[0]->DESCRIPTION?></p></div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Recently Viewed -->


	<!-- Brands -->

	<?php include('templates/brands.php')?>
	

	<!-- Newsletter -->

	<!-- Footer -->

	<?php include('templates/footer.php')?>
	
	<!-- Copyright -->
	
	<?php include('templates/copyright.php')?>
	
</div>

<script src="<?php echo base_url().'assets/'?>js/jquery-3.3.1.min.js"></script>
<script src="<?php echo base_url().'assets/'?>styles/bootstrap4/popper.js"></script>
<script src="<?php echo base_url().'assets/'?>styles/bootstrap4/bootstrap.min.js"></script>
<script src="<?php echo base_url().'assets/'?>plugins/greensock/TweenMax.min.js"></script>
<script src="<?php echo base_url().'assets/'?>plugins/greensock/TimelineMax.min.js"></script>
<script src="<?php echo base_url().'assets/'?>plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="<?php echo base_url().'assets/'?>plugins/greensock/animation.gsap.min.js"></script>
<script src="<?php echo base_url().'assets/'?>plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="<?php echo base_url().'assets/'?>plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="<?php echo base_url().'assets/'?>plugins/easing/easing.js"></script>
<script src="<?php echo base_url().'assets/'?>js/product_custom.js"></script>
</body>

</html>
