insert into CATEGORIE(nomcategorie) values ('Laptop');
insert into CATEGORIE(nomcategorie) values ('Smartphone');
insert into CATEGORIE(nomcategorie) values ('Graphiccards');


insert into PRODUIT(idcategorie, nomproduit, description, image) values (1, 'ROG Strix SCAR', 'ASUS ROG Strix Scar Edition GL703GE-ES73 17.3” Gaming Laptop, 8th-Gen', 'assets/images/rogscar.jpg');
